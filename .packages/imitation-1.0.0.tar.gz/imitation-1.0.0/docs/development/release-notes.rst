Release Notes
=============

.. changelog::
    :changelog-url: https://imitation.readthedocs.io/en/latest/development/release-notes.html
    :github: https://github.com/HumanCompatibleAI/imitation/releases
    :pypi: https://pypi.org/project/imitation/
