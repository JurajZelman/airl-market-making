---
name: Feature request
about: Suggest an idea for this project
title: ''
labels: enhancement
assignees: ''

---

## Problem
Description of what problem this feature request aims to solve.

## Solution
Description of proposed solution or change.

## Possible alternative solutions
Description of any alternative solutions or features you've considered.
