"""Adversarial imitation learning algorithms, AIRL and GAIL."""
