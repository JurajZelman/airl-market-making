"""Modules handling environment data.

For example: types for transitions/trajectories; methods to compute rollouts;
buffers to store transitions; helpers for these modules.
"""
