"""General utility functions: e.g. logging, configuration, etc."""
